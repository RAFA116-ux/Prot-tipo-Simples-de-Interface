/* Red Line Guitars - script.js
   Controle de navegação, formulário, catálogo e modal.
*/

document.addEventListener('DOMContentLoaded', () => {
  initializeNavigation();
  initializeMobileMenu();
  initializeCatalog();
  initializeRegisterForm();
  initializeLoginForm();
  initializeModal();
});

/* ========== NAV & MOBILE ========== */
function scrollToSection(sectionId) {
  const el = document.getElementById(sectionId);
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function initializeNavigation() {
  const navLinks = document.querySelectorAll('.nav-link, .nav-link-mobile');
  navLinks.forEach(link => {
    link.addEventListener('click', e => {
      e.preventDefault();
      const target = link.getAttribute('href').replace('#', '');
      scrollToSection(target);
      closeMobileMenu();
    });
  });
}

function initializeMobileMenu() {
  const menuToggle = document.getElementById('menuToggle');
  const navMobile = document.getElementById('navMobile');
  if (!menuToggle) return;

  menuToggle.addEventListener('click', () => {
    menuToggle.classList.toggle('active');
    navMobile.classList.toggle('active');
  });

  document.addEventListener('click', e => {
    if (!menuToggle.contains(e.target) && !navMobile.contains(e.target)) {
      closeMobileMenu();
    }
  });
}

function closeMobileMenu() {
  const menuToggle = document.getElementById('menuToggle');
  const navMobile = document.getElementById('navMobile');
  menuToggle.classList.remove('active');
  navMobile.classList.remove('active');
}

/* ========== CATÁLOGO / PRODUTOS ========== */
const PRODUCTS = [
  {
    id: 'gtr1',
    title: 'Vintage Tele Red',
    price: 'R$ 2.999,00',
    img: 'https://www.davesguitar.com/cdn/shop/files/DCS_0507-4.jpg?v=1703262367&width=',
    desc: 'Telecaster com vibe vintage e timbre brilhante. Ideal para country e rock clássico.'
  },
  {
    id: 'gtr2',
    title: 'GuitarLine Les Metal',
    price: 'R$ 3.799,00',
    img: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT8w6AAbJk-r8EeQy8rEh27zgHA_T8xsH5bB8o8u1Olb4AIsww_LY2CZ2TL8qeGayrdirk&usqp=CAU',
    desc: 'Modelo agressivo e potente, ideal para metal e hard rock. Captadores humbucker duplos.'
  },
  {
    id: 'gtr3',
    title: 'Acessórios Pack',
    price: 'R$ 199,00',
    img: 'https://ariosemusic.com/wp-content/uploads/2022/12/39-Inch-Red-01-1030x1030.jpg',
    desc: 'Kit com cabo, palhetas, correia e encordoamento. Tudo o que você precisa para tocar!'
  },
  {
    id: 'gtr4',
    title: 'Signature Explorer',
    price: 'R$ 4.950,00',
    img: 'https://i.ytimg.com/vi/WgJVKGeAX9g/hq720.jpg?sqp=-oaymwEhCK4FEIIDSFryq4qpAxMIARUAAAAAGAElAADIQj0AgKJD&rs=AOn4CLBlMri37W_c6iGf7qN7pcCs49r01Q',
    desc: 'Design inspirado em lendas do metal. Timbre pesado e presença de palco incomparável.'
  },
  {
    id: 'gtr5',
    title: 'Classic Acoustic Red',
    price: 'R$ 1.390,00',
    img: 'https://somosmusica.com.br/wp-content/uploads/2025/02/uma-ilustracao-que-mostra-a-variedade-de-violoes-acusticos-destacando-os-diferentes-designs-e-cores-.webp',
    desc: 'Violão acústico com acabamento vermelho, timbre encorpado e conforto ao tocar.'
  }
];

function initializeCatalog() {
  const grid = document.getElementById('productsGrid');
  if (!grid) return;

  grid.innerHTML = '';
  PRODUCTS.forEach(p => {
    const card = document.createElement('div');
    card.className = 'product-card';

    card.innerHTML = `
      <img class="product-thumb" src="${p.img}" alt="${p.title}">
      <div class="product-info">
        <h4>${p.title}</h4>
        <p class="muted">${p.desc}</p>
        <p class="price">${p.price}</p>
        <div style="margin-top:8px">
          <button class="btn btn-primary" data-id="${p.id}">Ver detalhes</button>
          <button class="btn" style="margin-left:8px;background:transparent;border:1px solid rgba(255,255,255,0.04);color:var(--muted)" data-buy="${p.id}">Adicionar</button>
        </div>
      </div>
    `;
    grid.appendChild(card);
  });

  grid.addEventListener('click', e => {
    const btn = e.target.closest('button');
    if (!btn) return;

    const pid = btn.getAttribute('data-id');
    const buyId = btn.getAttribute('data-buy');

    if (pid) {
      const product = PRODUCTS.find(x => x.id === pid);
      openProductModal(product);
    } else if (buyId) {
      addToCart(buyId);
    }
  });
}

function addToCart(id) {
  const product = PRODUCTS.find(x => x.id === id);
  if (!product) return;
  alert(`"${product.title}" adicionado ao carrinho (simulação).`);
}

/* ========== MODAL PRODUTO ========== */
function initializeModal() {
  const modal = document.getElementById('productModal');
  const closeBtn = document.getElementById('modalClose');

  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      modal.classList.remove('open');
    });
  }

  modal.addEventListener('click', e => {
    if (e.target === modal) modal.classList.remove('open');
  });

  const buyBtn = document.getElementById('buyBtn');
  buyBtn.addEventListener('click', () => {
    alert('Compra simulada! (Integração de pagamento na versão final)');
    modal.classList.remove('open');
  });
}

function openProductModal(product) {
  if (!product) return;
  document.getElementById('modalImage').src = product.img;
  document.getElementById('modalTitle').textContent = product.title;
  document.getElementById('modalDesc').textContent = product.desc;
  document.getElementById('modalPrice').textContent = product.price;
  document.getElementById('productModal').classList.add('open');
}

/* ========== CADASTRO ========== */
let formData = { name: '', email: '', password: '', confirmPassword: '', phone: '' };
let formErrors = {};

function initializeRegisterForm() {
  const form = document.getElementById('registerForm');
  if (!form) return;

  form.addEventListener('submit', e => {
    e.preventDefault();
    const fd = new FormData(form);
    for (const [k, v] of fd.entries()) formData[k] = v.trim();

    if (!validateForm()) return;

    const users = JSON.parse(localStorage.getItem('rl_users') || '[]');
    if (users.some(u => u.email === formData.email)) {
      showFieldError('email', 'E-mail já cadastrado');
      return;
    }

    const newUser = {
      id: 'u_' + Date.now(),
      name: formData.name,
      email: formData.email,
      phone: formData.phone,
      password: formData.password
    };
    users.push(newUser);
    localStorage.setItem('rl_users', JSON.stringify(users));

    alert('Cadastro realizado com sucesso! Faça login para acessar o catálogo.');
    form.reset();
    formData = { name: '', email: '', password: '', confirmPassword: '', phone: '' };
    formErrors = {};
    scrollToSection('login');
  });

  const inputs = form.querySelectorAll('.form-input');
  inputs.forEach(i => {
    i.addEventListener('input', ev => {
      const name = ev.target.name;
      const value = ev.target.value;
      formData[name] = value;
      clearFieldError(name);
    });
    i.addEventListener('blur', ev => {
      validateField(ev.target.name, ev.target.value);
    });
  });
}

function validateField(fieldName, value) {
  let isValid = true;
  let err = '';

  switch (fieldName) {
    case 'name':
      if (!value.trim()) { err = 'Nome é obrigatório'; isValid = false; }
      else if (value.trim().length < 2) { err = 'Nome muito curto'; isValid = false; }
      break;
    case 'email':
      if (!value.trim()) { err = 'E-mail é obrigatório'; isValid = false; }
      else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) { err = 'E-mail inválido'; isValid = false; }
      break;
    case 'phone':
      if (!value.trim()) { err = 'Telefone é obrigatório'; isValid = false; }
      else if (!/^\(?\d{2}\)?\s?\d{4,5}-\d{4}$/.test(value)) { err = 'Formato: (xx) xxxxx-xxxx'; isValid = false; }
      break;
    case 'password':
      if (!value) { err = 'Senha é obrigatória'; isValid = false; }
      else if (value.length < 6) { err = 'Mínimo 6 caracteres'; isValid = false; }
      break;
    case 'confirmPassword':
      if (!value) { err = 'Confirme sua senha'; isValid = false; }
      else if (value !== formData.password) { err = 'Senhas não coincidem'; isValid = false; }
      break;
  }

  if (!isValid) {
    showFieldError(fieldName, err);
    formErrors[fieldName] = err;
  } else {
    clearFieldError(fieldName);
    delete formErrors[fieldName];
  }
  return isValid;
}

function validateForm() {
  let ok = true;
  for (const key of ['name', 'email', 'phone', 'password', 'confirmPassword']) {
    const valid = validateField(key, formData[key] || '');
    if (!valid) ok = false;
  }
  return ok;
}

function showFieldError(fieldName, message) {
  const el = document.getElementById(fieldName);
  const err = document.getElementById(fieldName + 'Error');
  if (el) el.classList.add('error');
  if (err) { err.textContent = message; err.classList.add('show'); }
}

function clearFieldError(fieldName) {
  const el = document.getElementById(fieldName);
  const err = document.getElementById(fieldName + 'Error');
  if (el) el.classList.remove('error');
  if (err) { err.textContent = ''; err.classList.remove('show'); }
}

/* ========== LOGIN ========== */
function initializeLoginForm() {
  const form = document.getElementById('loginForm');
  const message = document.getElementById('loginMessage');
  if (!form) return;

  form.addEventListener('submit', e => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value;

    const users = JSON.parse(localStorage.getItem('rl_users') || '[]');
    const user = users.find(u => u.email === email && u.password === password);

    if (user) {
      message.textContent = `Bem-vindo, ${user.name.split(' ')[0]}! Redirecionando...`;
      message.style.color = '#b3ffb3';
      setTimeout(() => {
        scrollToSection('catalog');
        message.textContent = '';
      }, 900);
    } else {
      message.textContent = 'E-mail ou senha incorretos.';
      message.style.color = '#ffb3b3';
    }
  });
}
